from datawhispers.datavis import *
from advanced_prog import *