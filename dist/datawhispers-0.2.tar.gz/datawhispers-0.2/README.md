# The DataWhispers module is used for solving regression and statistical problems

## It was programmed for exams in advanced programming and data visualisation at DHBW Mannheim

### Solve regression problems (lin, poly, trig, free, least_squares), plot the results or do some statistical analysis with chi2, pearson or student-t

#### To install just write "pip install datawhispers" in your command prompt of choice
